using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEditorInternal.Profiling.Memory.Experimental.FileFormat;
using UnityEngine;
using static UnityEngine.RuleTile.TilingRuleOutput;

[Serializable]
public class PokemonData
{
    public string pokemonName;
    public int pokemonID;
    public Sprite pokemonSprite;
    [HideInInspector] public int pv;                  //pv var used during combat, to preserve BasePV data in the database
    [HideInInspector] public enum PokemonTypes
    {
        None,
        Normal,
        Fire,
        Water,
        Electric,
        Grass,
        Ice,
        Fighting,
        Poison,
        Ground,
        Flying,
        Psychic,
        Bug,
        Rock,
        Ghost,
        Dragon,
        Dark,
        Steel,
        Fairy,
        Stellar
    }
    public PokemonTypes[] types;
    public PokemonTypes[] resistant;
    public PokemonTypes[] weakness;
    [SerializeField] public PokemonData Enemy;

    [Serializable]

    public struct Infos
    {
        public string caption;
        public float height;
        public float weight;

        public Infos(string caption, float height, float weight)
        {
            this.caption = caption;
            this.height = height;
            this.weight = weight;
        }
    }

    [Serializable]

    public struct Stats
    {
        [Min(0)] public int basePV;
        [Min(0)] public int atk;
        [Min(0)] public int def;
        [Min(0)] public int atkSpe;
        [Min(0)] public int defSpe;
        [Min(0)] public int speed;

        public Stats(int pv, int atk, int def, int atkSpe, int defSpe, int speed)
        {
            this.basePV = pv;
            this.atk = atk;
            this.def = def;
            this.atkSpe = atkSpe;
            this.defSpe = defSpe;
            this.speed = speed;
        }

        public Stats(Stats statsBase, int coeff)
        {
            basePV = statsBase.basePV * coeff;
            atk = statsBase.atk * coeff;
            def = statsBase.def * coeff;
            atkSpe = statsBase.atkSpe * coeff;
            defSpe = statsBase.defSpe * coeff;
            speed = statsBase.speed * coeff;
        }

        public Stats GetStatsByLvl(Stats statsBase, int level, int evolutionStep)
        {
            var coeff = level * evolutionStep / 10;
            return new Stats(statsBase, coeff);
        }
    }

    public Infos infos;
    public Stats statsBase;

    public PokemonData(string pokemonName, int pokemonID, PokemonTypes[] types, PokemonTypes[] resistant, PokemonTypes[] weakness, Sprite pokemonSprite, Infos infos)
    {
        this.pokemonName = pokemonName;
        this.pokemonID = pokemonID;
        this.infos = infos;
        this.types = types;
        this.resistant = resistant;
        this.weakness = weakness;
        this.pokemonSprite = pokemonSprite;
    }

    public void TakeDamage(PokemonData Enemy)
    {
        int damage = Enemy.statsBase.atk;
        if (CheckTypes(weakness, Enemy.types))
        {
            damage *= 2;
            Debug.Log($"Damage doubled due to {pokemonName} weakness.");
        }
        else if (CheckTypes(resistant, Enemy.types))
        {
            damage /= 2;
            Debug.Log($"Damage halfed due to {pokemonName} resistance.");
        }
        pv = Mathf.Clamp(pv - damage, 0, pv);
        Debug.Log($"{pokemonName} took {damage} points of damage.");
        Debug.Log(IsPokemonAlive() ? $"{pokemonName} still alive and has {pv}pv left." : $"{pokemonName} died.");
    }

    public void AttackOpponent(PokemonData Enemy)
    {
        if(IsPokemonAlive() && Enemy.IsPokemonAlive())
        {
            Debug.Log($"{pokemonName} attacked {Enemy.pokemonName}");
            Enemy.TakeDamage(this);
        }
        if (!IsPokemonAlive())
            Debug.Log("This Pokemon can not attack.");
    }

    bool CheckTypes(PokemonTypes[] thispokemon, PokemonTypes[] enemy)
    {
        foreach (PokemonTypes type in enemy)
        {
            foreach(PokemonTypes poketype in thispokemon)
            if (type == poketype)
            {
                return true;
            }
        }
        return false;
    }

    bool IsPokemonAlive()
    {
        return pv > 0;
    }
}
