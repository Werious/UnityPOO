using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEditor.PlayerSettings;
using static UnityEngine.EventSystems.EventTrigger;
using UnityEngine.SocialPlatforms.Impl;

[CreateAssetMenu(fileName = "Pokemon Database", menuName = "Pokemons/New Database", order = 0)]
public class PokemonDatabase : ScriptableObject
{
    public List<PokemonData> datas = new();
    public void CreateData()
    {
        if (datas.Exists(x => x.pokemonName == "Pikachu"))
            return;
        PokemonData.Infos infos = new("When it is angered, it immediately discharges the energy stored in the pouches in its cheeks", 0.4f, 6f);

        PokemonData poke = new(
        pokemonName: "Pikachu",
        pokemonID: 25,
        types: null,
        resistant: null,
        weakness: null,
        pokemonSprite: null,
        infos: infos) ;

        datas.Add(poke);
    }
}
