using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PokemonController : MonoBehaviour
{

    private DatabaseManager databaseManager;

    private void Awake()
    {
        databaseManager = FindObjectOfType<DatabaseManager>();
    }

    private void Start()
    {
        databaseManager.database.datas[0].AttackOpponent(databaseManager.database.datas[9]);      //Eevee attack Xerneas
        databaseManager.database.datas[9].AttackOpponent(databaseManager.database.datas[0]);      //Xerneas attack Eevee
    }

    private void DelayAttack(PokemonData pokemon)
    {
        pokemon.AttackOpponent(pokemon.Enemy);
        StartCoroutine(Delay());
    }

    IEnumerator Delay()
    {
        yield return new WaitForSeconds(UnityEngine.Random.Range(1.25f, 3.1f));
    }
}
