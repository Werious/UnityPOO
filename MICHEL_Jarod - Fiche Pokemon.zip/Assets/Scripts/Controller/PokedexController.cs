using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Windows;

public class PokedexController : MonoBehaviour
{
    private DatabaseManager databaseManager;

    [SerializeField][Min(0)] public int Index;
    [Header("References")]
    [SerializeField] private TMP_Text TXTname;
    [SerializeField] private TMP_Text TXTdescription;
    [SerializeField] private TMP_Text TXTID;
    [SerializeField] private TMP_Text TXTheight;
    [SerializeField] private TMP_Text TXTweight;
    [SerializeField] private TMP_Text TXTtypes;
    [Header("Stats")]
    [SerializeField] private TMP_Text TXTpv;
    [SerializeField] private TMP_Text TXTattack;
    [SerializeField] private TMP_Text TXTdefense;
    [SerializeField] private TMP_Text TXTattackSP;
    [SerializeField] private TMP_Text TXTdefenseSP;
    [SerializeField] private TMP_Text TXTspeed;
    [SerializeField] private UnityEngine.UI.Image pokemonImage;


    private void Awake()
    {
        databaseManager = FindObjectOfType<DatabaseManager>();
        foreach(PokemonData pokemon in databaseManager.database.datas)
        {
            pokemon.pv = pokemon.statsBase.basePV;
        }
    }

    private void Start()
    {
        UpdateInfos();
    }

    void UpdateInfos()
    {
        PokemonData CurrentPokemon = databaseManager.GetData(Index);
        TXTname.text = $"Name: {CurrentPokemon.pokemonName}";
        TXTdescription.text = $"Description :\n{CurrentPokemon.infos.caption}";
        TXTID.text = $"#{CurrentPokemon.pokemonID.ToString("D4")}";
        TXTheight.text = $"Height : {CurrentPokemon.infos.height.ToString("f1")}m";
        TXTweight.text = $"Weight : {CurrentPokemon.infos.weight.ToString("f1")}kg";
        TXTtypes.text = $"Types : {ShowTypes(CurrentPokemon)}";
        pokemonImage.sprite = CurrentPokemon.pokemonSprite;

        TXTpv.text = $"PV : {CurrentPokemon.statsBase.basePV}";
        TXTattack.text = $"Atk : {CurrentPokemon.statsBase.atk}";
        TXTdefense.text = $"Def : {CurrentPokemon.statsBase.def}";
        TXTattackSP.text = $"AtkSpe : {CurrentPokemon.statsBase.atkSpe}";
        TXTdefenseSP.text = $"DefSpe : {CurrentPokemon.statsBase.defSpe}";
        TXTspeed.text = $"Speed : {CurrentPokemon.statsBase.speed}";
    }

    string ShowTypes(PokemonData CurrentPokemon)
    {
        string msg = "";
        foreach (PokemonData.PokemonTypes type in CurrentPokemon.types)
        {
            msg += string.Join(" ", type);
            msg += " ";
        }
        return msg;
    }

    public void ChangePage(int value)
    {
        Index = Mathf.Clamp(Index + value, 0, databaseManager.database.datas.Count - 1);
        UpdateInfos();
    }

    public void Search(TMP_InputField input)
    {
        foreach(PokemonData pokemon in databaseManager.database.datas)
        {
            if(pokemon.pokemonID.ToString() == input.text || pokemon.pokemonName.ToLower().Contains(input.text.ToLower()))
            {
                Index = databaseManager.database.datas.IndexOf(pokemon);
                UpdateInfos();
                break;
            }
        }
    }

}
